// write auth context for jwt based auth in spring boot backend
import React, { createContext, useState } from 'react';
export const AuthContext = createContext();
export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({
    username: null,
    token: null
  });
  const setAuthData = (data) => {
    setAuth(data);
  };
  return (
    <AuthContext.Provider value={{ auth, setAuthData }}>
      {children}
    </AuthContext.Provider>
  );
};
