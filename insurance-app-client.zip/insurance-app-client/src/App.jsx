import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './components/Profile';
import ProtectedRoute from './utils/ProtectedRoute';
import UnprotectedRoute from './utils/UnprotectedRoute';
import { AuthProvider } from './context/AuthContext';
function App() {
  return (
    <AuthProvider>
      <Router>
        <Switch>
          <Route path="/login" component={Login} />
          <UnprotectedRoute path="/register" component={Register} />
          <ProtectedRoute path="/profile" component={Profile} />
        </Switch>
      </Router>
    </AuthProvider>
  );
}

export default App;
